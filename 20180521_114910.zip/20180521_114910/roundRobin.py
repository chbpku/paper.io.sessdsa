# -*- coding: utf-8 -*-
import time

timeout= 1.0 # singlestep timeout

def race(blackName, blackPlay, whiteName, whitePlay):
    from match_core import match
    match_result = match(blackName, blackPlay, whiteName, whitePlay, k=25, h=49)

    print(match_result['players'])
    print(match_result['result'])
    
    doc = open(str(blackName) + '_versus_' + str(whiteName) + '.txt', 'w')
    print(match_result, file = doc)
    doc.close()
    

import os
players= []
#取得所有以T_开始文件名的算法文件名
for root, dirs, files in os.walk('.'):
    for name in files:
        if name[:2]== 'T_' and name[-3:]== '.py': #以T_开始，以.py结尾
            players.append(name[:-3]) #去掉.py后缀

for blackName in players:
    for whiteName in players:
        exec('import %s as BP' % (blackName))
        exec('import %s as WP' % (whiteName))
        race(blackName, BP.play, whiteName, WP.play)
